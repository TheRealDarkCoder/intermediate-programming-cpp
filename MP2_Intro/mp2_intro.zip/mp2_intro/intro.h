#pragma once

#include "RGBA/png.h"

#include <string>

void rotate(const std::string & inputFile, const std::string & outputFile);
PNG myArt(unsigned int width, unsigned int height);
