#include <iostream>

int main(){
    // prints "Hello, world"
    std::cout << "Hello, world!\n";
}
